"""
Data Management Helper Functions.
This module provides helper functions for working with Data Management tables in Python notebooks.
"""

import pandas as pd
import numpy as np
import json
import asyncio
import sys
from typing import Any, Dict, List, Optional, Tuple, Callable, Union

# ---------- configuration ---------- #
DEBUG = False


def set_debug(flag: bool):
    """
    Enable or disable debug logging for underlying Data Management actions.

    :param flag: True to enable verbose logging, False to disable.
    """
    global DEBUG
    DEBUG = flag


def _log(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)


def _get_grist():
    """Get the grist module from sys.modules"""
    import sys
    
    # Debug: Print all available modules
    if DEBUG:
        print(f"Available modules: {list(sys.modules.keys())}")
        grist_related = [m for m in sys.modules.keys() if 'grist' in m.lower()]
        print(f"Grist-related modules: {grist_related}")
    
    if 'grist' not in sys.modules:
        # Try alternative ways to access grist
        try:
            import grist as grist_module
            if DEBUG:
                print("Successfully imported grist directly")
            return grist_module
        except ImportError:
            pass
        
        # Check if it's available as a global
        try:
            if 'grist' in globals():
                if DEBUG:
                    print("Found grist in globals")
                return globals()['grist']
        except:
            pass
            
        # Try to find it in builtins
        try:
            import builtins
            if hasattr(builtins, 'grist'):
                if DEBUG:
                    print("Found grist in builtins")
                return builtins.grist
        except:
            pass
        
        raise RuntimeError(f"Grist API not available - this code must run in a Grist sandbox. Available modules: {list(sys.modules.keys())[:10]}...")
    
    grist_module = sys.modules['grist']
    if DEBUG:
        print(f"Found grist module: {grist_module}")
        print(f"Grist module attributes: {dir(grist_module)}")
        if hasattr(grist_module, 'raw'):
            print(f"Grist.raw attributes: {dir(grist_module.raw)}")
            if hasattr(grist_module.raw, 'docApi'):
                print(f"Grist.raw.docApi attributes: {dir(grist_module.raw.docApi)}")
    
    return grist_module
        

def _pd_to_grist_type(dtype) -> str:
    """
    Map a pandas dtype to a Grist column type.
    """
    mapping = {
        'int64':    'Numeric',
        'int32':    'Numeric',
        'float64':  'Numeric',
        'float32':  'Numeric',
        'bool':     'Bool',
        'datetime64[ns]': 'Date',
        'object':   'Text',
        'category': 'Text',
    }
    return mapping.get(str(dtype), 'Text')


async def _safe_apply(actions: List[List[Any]]) -> Any:
    """
    Safely apply Data Manager user actions with optional debug logging and retry.

    :param actions: List of user-action lists to apply.
    :returns: The raw result from applyUserActions.
    """
    if DEBUG:
        _log(f"[apply] {actions!r}")
    
    grist = _get_grist()
    
    try:
        return await grist.raw.docApi.applyUserActions(actions)
    except Exception as e:
        _log(f"[retry] {e!r}")
        await asyncio.sleep(0.4)
        return await grist.raw.docApi.applyUserActions(actions)

# ---------- utility functions ---------- #

def _sanitize(v: Any) -> Any:
    """
    Convert numpy/pandas types and NaN to JSON-serializable Python types.

    :param v: The value to sanitize.
    :returns: A JSON-friendly primitive or None.
    """
    if pd.isna(v):
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    return v


def _safe_col(col: str) -> str:
    """
    Safely convert column names, avoiding reserved 'id'.

    :param col: Original column name.
    :returns: 'ID_field' if name is 'id', else original name.
    """
    return "ID_field" if col.strip().lower() == "id" else col


async def _column_map(table: str) -> Dict[str, str]:
    """
    Fetch a mapping from lowercase column names to actual field IDs.

    :param table: Table name to inspect.
    :returns: Dict mapping lowercase names to actual Grist field IDs.
    """
    grist = _get_grist()
    data = await grist.fetch_table(table)
    return {c.lower(): c for c in data.keys()}


# ─── AsyncDataFramePipeline for chaining helpers ---------- #
class AsyncDataFramePipeline:
    """
    A lightweight "fluent" pipeline for chaining together
    pandas‐based transformations *and* Grist helper calls.

    Usage pattern:
      pipeline = (
        AsyncDataFramePipeline()
          .then(fetch_table_to_dataframe, "MyTable")    # step 1: load
          .then(lambda df: df[df.Score > 50])           # step 2: filter
          .then(add_ratio)                              # step 3: sync transform
          .then(enrich_flag, threshold=1.5)             # step 4: async transform
      )
      result_df = await pipeline.run()
    """

    def __init__(self):
        # Internal list of (func, args, kwargs) tuples to execute in order
        self._steps: List[Tuple[Callable, Tuple[Any, ...], dict]] = []

    def then(self, func: Callable, *args: Any, **kwargs: Any) -> "AsyncDataFramePipeline":
        """
        Schedule a new pipeline step.

        - On the *first* step: calls `func(*args, **kwargs)`.
        - On *subsequent* steps: calls `func(df, *args, **kwargs)` where `df`
          is the DataFrame returned by the previous step.

        :param func:   A synchronous (`def`) or async (`async def`) function.
        :param args:   Positional arguments for `func`.
        :param kwargs: Keyword arguments for `func`.
        :returns:      `self` (allows chaining).
        """
        self._steps.append((func, args, kwargs))
        return self

    async def run(self) -> pd.DataFrame:
        """
        Execute all scheduled steps in order and return the final DataFrame.

        - Automatically `await`s any async step.
        - Passes the previous step's DataFrame into the next step.
        - If the very first step returns anything but a DataFrame,
          that becomes the "df" passed to the next step.

        :returns: The DataFrame (or last return value) from the final step.
        """
        df: Union[pd.DataFrame, Any] = None

        for index, (func, args, kwargs) in enumerate(self._steps):
            if index == 0:
                # First step: call without df injection
                result = func(*args, **kwargs)
            else:
                # Later steps: inject the DataFrame (or last result)
                if asyncio.iscoroutinefunction(func):
                    result = await func(df, *args, **kwargs)
                else:
                    result = func(df, *args, **kwargs)

            # If the result is a coroutine (async def used incorrectly), await it
            df = await result if asyncio.iscoroutine(result) else result

        # At the end, df holds the output of the last step
        return df


# ---------- AsyncPipeline for Helper Functions ---------- #
class AsyncPipeline:
    """
    A lightweight async pipeline for chaining arbitrary helper functions.
    
    Each step in the pipeline can either:
      - Inject the previous step's result as the first argument (.then)
      - Always run standalone with its own arguments (.then_no_prev)
      
    After scheduling your steps, call `await pipeline.run()` once to execute
    them sequentially. Async functions are awaited; sync functions are called directly.
    """
    def __init__(self, initial: Any = None):
        """
        :param initial: An optional initial value passed into the first step
                        if you use .then(). If None, first step is always
                        called without injection.
        """
        self.value = initial
        # Each entry: (func, args, kwargs, inject_flag)
        self._steps: List[Tuple[Callable, Tuple[Any, ...], dict, bool]] = []

    def then(self, func: Callable, *args: Any, **kwargs: Any) -> "AsyncPipeline":
        """
        Schedule a step that **injects** the previous result if non-None.
        
        :param func:   The callable (sync or async) to invoke.
        :param args:   Positional arguments for func.
        :param kwargs: Keyword arguments for func.
        :returns:      self, for chaining.
        
        Behavior:
        - If self.value is not None, calls func(self.value, *args, **kwargs).
        - Otherwise, calls func(*args, **kwargs).
        """
        self._steps.append((func, args, kwargs, True))
        return self

    def then_no_prev(self, func: Callable, *args: Any, **kwargs: Any) -> "AsyncPipeline":
        """
        Schedule a step that **never** injects the previous result.
        
        :param func:   The callable to invoke.
        :param args:   Positional arguments for func.
        :param kwargs: Keyword arguments for func.
        :returns:      self, for chaining.
        
        Behavior: Always calls func(*args, **kwargs), ignoring self.value.
        """
        self._steps.append((func, args, kwargs, False))
        return self

    async def run(self) -> Any:
        """
        Execute all scheduled steps in sequence.
        
        :returns: The return value of the final step in the pipeline.
        """
        for func, args, kwargs, inject in self._steps:
            # Decide call signature
            if inject and self.value is not None:
                result = func(self.value, *args, **kwargs)
            else:
                result = func(*args, **kwargs)
            # Await if it's a coroutine
            self.value = await result if asyncio.iscoroutine(result) else result
        return self.value


class TableOperations:
    """Main class containing all table operation methods."""
    
    # ---------- table/schema operations ---------- #

    @staticmethod
    async def create_table(table_name: str, columns: Dict[str, str]) -> bool:
        """
        Create a new table and add specified visible columns.

        :param table_name: Identifier for the new table.
        :param columns: Mapping of column label -> Grist type (e.g., 'Text').
        :returns: True on success, False on error.
        """
        try:
            if DEBUG:
                print(f"🔧 DEBUG: create_table called with table_name='{table_name}', columns={columns}")
            
            # Step 1: Create the table
            if DEBUG:
                print(f"🔧 DEBUG: About to call AddTable action")
            
            result1 = await _safe_apply([['AddTable', table_name, []]])
            
            if DEBUG:
                print(f"🔧 DEBUG: AddTable result: {result1}")
            
            # Step 2: Add columns
            actions = []
            for label, typ in columns.items():
                field_id = _safe_col(label)
                if DEBUG:
                    print(f"🔧 DEBUG: Processing column '{label}' -> field_id '{field_id}', type '{typ}'")
                
                actions.append([
                    'AddVisibleColumn', table_name, field_id,
                    {'type': typ, 'label': label, 'widgetOptions': '', 'formula': ''}
                ])
            
            if actions:
                if DEBUG:
                    print(f"🔧 DEBUG: About to apply column actions: {actions}")
                
                result2 = await _safe_apply(actions)
                
                if DEBUG:
                    print(f"🔧 DEBUG: AddVisibleColumn result: {result2}")
            
            if DEBUG:
                print(f"🔧 DEBUG: create_table completed successfully")
            
            return True
        except Exception as e:
            print(f"❌ create_table error: {e!r}")
            print(f"❌ Exception type: {type(e)}")
            import traceback
            print(f"❌ Full traceback:\n{traceback.format_exc()}")
            return False

    @staticmethod
    async def remove_table(table_name: str) -> bool:
        """
        Remove an existing table and all its data.

        :param table_name: Identifier of the table to remove.
        :returns: True on success, False on error.
        """
        try:
            await _safe_apply([['RemoveTable', table_name]])
            return True
        except Exception as e:
            _log(f"❌ remove_table error: {e!r}")
            return False

    @staticmethod
    async def update_table(
        table_name: str,
        new_columns: Optional[Dict[str, str]] = None,
        rename_columns: Optional[Dict[str, str]] = None
    ) -> bool:
        """
        Add new columns or rename existing columns on a table.

        :param table_name: The table to modify.
        :param new_columns: Dict of new columns label->type.
        :param rename_columns: Dict of old_field_id->new_field_id.
        :returns: True on success, False on error.
        """
        try:
            actions: List[List[Any]] = []
            if new_columns:
                for label, typ in new_columns.items():
                    actions.append(['AddColumn', table_name, label, {'type': typ}])
            if rename_columns:
                for old, new in rename_columns.items():
                    actions.append(['RenameColumn', table_name, old, new])
            if actions:
                await _safe_apply(actions)
            return True
        except Exception as e:
            _log(f"❌ update_table error: {e!r}")
            return False

    @staticmethod
    async def change_column_type(
        table_name: str,
        col_id: str,
        new_type: str,
        label: Optional[str] = None
    ) -> bool:
        """
        Change a column's type (and optionally its label).

        :param table_name: The table containing the column.
        :param col_id: Internal field ID of the column to modify.
        :param new_type: New Grist data type (e.g. 'Text', 'Numeric').
        :param label: Optional new display label.
        :returns: True on success, False on error.
        """
        try:
            payload: Dict[str, Any] = {'type': new_type}
            if label is not None:
                payload['label'] = label
            await _safe_apply([['ModifyColumn', table_name, col_id, payload]])
            return True
        except Exception as e:
            _log(f"❌ change_column_type error: {e!r}")
            return False

    @staticmethod
    async def rename_table(old_name: str, new_name: str) -> bool:
        """
        Rename an entire table.

        :param old_name: Current table ID.
        :param new_name: Desired new table ID.
        :returns: True on success, False on error.
        """
        try:
            await _safe_apply([['RenameTable', old_name, new_name]])
            return True
        except Exception as e:
            _log(f"❌ rename_table error: {e!r}")
            return False

    @staticmethod
    async def remove_column(table: str, col_id: str) -> bool:
        """
        Remove a single column from a table.

        :param table: Table ID.
        :param col_id: Field ID of the column to drop.
        :returns: True on success, False on error.
        """
        try:
            await _safe_apply([['RemoveColumn', table, col_id]])
            return True
        except Exception as e:
            _log(f"❌ remove_column error: {e!r}")
            return False

    @staticmethod
    async def replace_table_data(table: str, bulk_values: Dict[str, List[Any]]) -> bool:
        """
        Atomically replace all rows in a table.

        :param table: Table ID.
        :param bulk_values: Mapping of field ID->list of values.
        :returns: True on success, False on error.
        """
        try:
            await _safe_apply([['ReplaceTableData', table, [], bulk_values]])
            return True
        except Exception as e:
            _log(f"❌ replace_table_data error: {e!r}")
            return False

    @staticmethod
    async def modify_column(
        table: str,
        col_id: str,
        props: Dict[str, Any]
    ) -> bool:
        """
        Modify arbitrary column properties (widgetOptions, formula, etc.).

        :param table: Table ID.
        :param col_id: Field ID.
        :param props: Dict of properties to set.
        :returns: True on success, False on error.
        """
        try:
            await _safe_apply([['ModifyColumn', table, col_id, props]])
            return True
        except Exception as e:
            _log(f"❌ modify_column error: {e!r}")
            return False

    # ---------- record-level operations ---------- #

    @staticmethod
    async def add_data(table_name: str, records: Union[Dict[str, Any], List[Dict[str, Any]]]) -> Optional[List[int]]:
        """
        Bulk-add records to a table, returning new row IDs.

        :param table_name: Table to insert into.
        :param records: List of dicts mapping label->value.
        :returns: List of new row IDs, or None on error.
        """
        if isinstance(records, dict):
            records = [records]
        if not records:
            return []
        try:
            cmap = await _column_map(table_name)
            row_ids: List[int] = []
            for rec in records:
                clean = {cmap[k.lower()]: _sanitize(v) for k, v in rec.items() if k.lower() in cmap}
                resp = await _safe_apply([['AddRecord', table_name, None, clean]])
                rid = resp['retValues'][0] if isinstance(resp, dict) else resp[0]
                row_ids.append(rid)
            return row_ids
        except Exception as e:
            _log(f"❌ add_data error: {e!r}")
            return None

    @staticmethod
    async def delete_data(
        table_name: str,
        row_ids: Optional[List[int]] = None,
        where: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Delete rows by explicit IDs or by a simple equality filter.

        :param table_name: Table ID.
        :param row_ids: List of row IDs to remove.
        :param where: Dict of label->value to match for deletion.
        :returns: True on success, False on error.
        """
        try:
            if row_ids:
                await _safe_apply([['RemoveRecord', table_name, rid] for rid in row_ids])
                return True
            if where:
                grist = _get_grist()
                data = await grist.fetch_table(table_name)
                cmap = {c.lower(): c for c in data.keys()}
                to_remove = [rid for i, rid in enumerate(data['id']) if all(data[cmap[k.lower()]][i] == v for k, v in where.items())]
                if to_remove:
                    await _safe_apply([['RemoveRecord', table_name, rid] for rid in to_remove])
                return True
            return False
        except Exception as e:
            _log(f"❌ delete_data error: {e!r}")
            return False

    @staticmethod
    async def update_record(table_name: str, row_id: int, updates: Dict[str, Any]) -> bool:
        """
        Update a single row's fields.

        :param table_name: Table containing the row.
        :param row_id: Numeric ID of the row.
        :param updates: Dict of label->new value.
        :returns: True on success, False on error.
        """
        try:
            cmap = await _column_map(table_name)
            clean = {cmap[k.lower()]: _sanitize(v) for k, v in updates.items() if k.lower() in cmap}
            await _safe_apply([['UpdateRecord', table_name, row_id, clean]])
            return True
        except Exception as e:
            _log(f"❌ update_record error: {e!r}")
            return False

    @staticmethod
    async def update_records(
        table_name: str,
        updates: List[Dict[str, Any]]
    ) -> List[bool]:
        """
        Apply multiple row updates sequentially.

        :param table_name: The Grist table to update.
        :param updates: List of dicts each with 'id': rowId plus any fields to set.
        :returns: List of booleans for each update's success.
        """
        results: List[bool] = []
        for rec in updates:
            row_id = rec.get('id')
            if row_id is None:
                results.append(False)
                continue
            data = {k: v for k, v in rec.items() if k != 'id'}
            ok = await TableOperations.update_record(table_name, row_id, data)
            results.append(ok)
        return results

    # ---------- DataFrame interop & merges ---------- #

    @staticmethod
    async def fetch_table_to_dataframe(table_name: str) -> pd.DataFrame:
        """
        Fetch a Grist table into a pandas DataFrame, dropping internal columns.

        :param table_name: Table ID.
        :returns: DataFrame without 'id' or 'manualSort'.
        """
        try:
            grist = _get_grist()
            data = await grist.fetch_table(table_name)
            df = pd.DataFrame(data).drop(columns=['id','manualSort'], errors='ignore')
            rename = {c: c[:-6] for c in df.columns if c.endswith('_field')}
            return df.rename(columns=rename)
        except Exception as e:
            _log(f"❌ fetch_table_to_dataframe error: {e!r}")
            return pd.DataFrame()

    @staticmethod
    async def create_table_from_dataframe(table_name: str, df: pd.DataFrame) -> Optional[str]:
        """
        Create a new table from a DataFrame and bulk-populate it.

        :param table_name: Desired table ID.
        :param df: Source DataFrame.
        :returns: Table ID on success, None on error.
        """
        if df.empty:
            return None
        try:
            cols = {col: _pd_to_grist_type(dt) for col, dt in df.dtypes.items()}
            if not await TableOperations.create_table(table_name, cols):
                return None
            recs = df.where(pd.notna(df), None).to_dict('records')
            if await TableOperations.add_data(table_name, recs) is None:
                return None
            return table_name
        except Exception as e:
            _log(f"❌ create_table_from_dataframe error: {e!r}")
            return None

    @staticmethod
    async def merge_tables(
        sources: List[str],
        target: Optional[str] = None,
        create_new: bool = False
    ) -> bool:
        """
        Append rows from multiple source tables into a single target table.

        :param sources: List of source table IDs.
        :param target: Target table ID (first source if None).
        :param create_new: Whether to create a new target table.
        :returns: True on success, False on error.
        """
        try:
            if len(sources) < 2:
                return False
            tgt, srcs = (target, sources) if target else (sources[0], sources[1:])
            if create_new:
                grist = _get_grist()
                schema = await grist.fetch_table(srcs[0])
                cols = {c: _pd_to_grist_type(next((v for v in schema[c] if v), None))
                        for c in schema if c not in ('id','manualSort')}
                await TableOperations.create_table(tgt, cols)
            for s in srcs:
                grist = _get_grist()
                data = await grist.fetch_table(s)
                rows = [{c: data[c][i] for c in data if c not in ('id','manualSort')}
                        for i in range(len(data.get('id', [])))]
                await TableOperations.add_data(tgt, rows)
            return True
        except Exception as e:
            _log(f"❌ merge_tables error: {e!r}")
            return False

    @staticmethod
    async def merge_tables_strict(
        sources: List[str],
        target: Optional[str] = None,
        create_new: bool = False
    ) -> bool:
        """
        Append only shared columns from multiple tables.

        :param sources: List of source table IDs.
        :param target: Target table ID (first source if None).
        :param create_new: Whether to create a new target table.
        :returns: True on success, False on error.
        """
        try:
            if len(sources) < 2:
                return False
            tgt, srcs = (target, sources) if target else (sources[0], sources[1:])
            if create_new:
                grist = _get_grist()
                schema = await grist.fetch_table(srcs[0])
                cols = {c: _pd_to_grist_type(next((v for v in schema[c] if v), None))
                        for c in schema if c not in ('id','manualSort')}
                await TableOperations.create_table(tgt, cols)
            grist = _get_grist()
            tgt_data = await grist.fetch_table(tgt)
            tgt_cols = [c for c in tgt_data if c not in ('id','manualSort')]
            for s in srcs:
                data = await grist.fetch_table(s)
                rows = [{c: data[c][i] for c in tgt_cols if c in data}
                        for i in range(len(data.get('id', [])))]
                await TableOperations.add_data(tgt, rows)
            return True
        except Exception as e:
            _log(f"❌ merge_tables_strict error: {e!r}")
            return False

    # ---------- document-level helpers ---------- #

    @staticmethod
    async def list_tables() -> List[str]:
        """
        List all table IDs in the current document.

        :returns: Ordered list of table IDs.
        """
        grist = _get_grist()
        return await grist.raw.docApi.listTables()

    @staticmethod
    async def get_doc_id() -> str:
        """
        Get the current document's unique identifier.

        :returns: Document ID string.
        """
        grist = _get_grist()
        return await grist.raw.docApi.getDocName()

    @staticmethod
    async def get_access_token(options: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fetch an access token for Grist API integrations.

        :param options: Options for token generation.
        :returns: Dict containing token and metadata.
        """
        grist = _get_grist()
        return await grist.raw.docApi.getAccessToken(options)


# Create an instance for backward compatibility
table_operations = TableOperations()

# Export all the functions at module level for convenience
# Add a quick debug enabler
def enable_debug():
    """Quick function to enable debug mode"""
    set_debug(True)
    print("🔧 DEBUG MODE ENABLED - You'll see detailed logs of all operations")

create_table = TableOperations.create_table
remove_table = TableOperations.remove_table
add_data = TableOperations.add_data
delete_data = TableOperations.delete_data
update_table = TableOperations.update_table
change_column_type = TableOperations.change_column_type
rename_table = TableOperations.rename_table
remove_column = TableOperations.remove_column
replace_table_data = TableOperations.replace_table_data
modify_column = TableOperations.modify_column
update_record = TableOperations.update_record
update_records = TableOperations.update_records
fetch_table_to_dataframe = TableOperations.fetch_table_to_dataframe
create_table_from_dataframe = TableOperations.create_table_from_dataframe
merge_tables = TableOperations.merge_tables
merge_tables_strict = TableOperations.merge_tables_strict
list_tables = TableOperations.list_tables
get_doc_id = TableOperations.get_doc_id
get_access_token = TableOperations.get_access_token