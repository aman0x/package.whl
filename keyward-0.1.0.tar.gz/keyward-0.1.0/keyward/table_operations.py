import grist

# --- Attachments ---
async def get_attachment_url(record, attachment_column):
    """
    Get the URL for an attachment in a record.

    Args:
        record (dict): The record containing the attachment
        attachment_column (str): The name of the attachment column

    Returns:
        str: URL to access the attachment
    """
    try:
        if not record or attachment_column not in record or not record[attachment_column]:
            return None

        # Get the attachment ID (first one if there are multiple)
        attachment_id = record[attachment_column][0] if isinstance(record[attachment_column], list) else record[attachment_column]

        # Get an access token
        token_info = await grist.docApi.getAccessToken({"readOnly": True})

        # Construct the URL
        url = f"{token_info.baseUrl}/attachments/{attachment_id}/download?auth={token_info.token}"

        return url

    except Exception as e:
        print(f"\u274c Error getting attachment URL: {e}")
        return None

# --- Advanced Operations ---

async def merge_tables_strict(source_table_names, target_table_name=None, create_new=False):
    """
    Merge multiple tables by appending data only to columns with matching names.
    Columns that don't exist in both source and target tables will be skipped.

    Args:
        source_table_names (list): List of table names to merge
        target_table_name (str, optional): Name of the target table. If None, data will be merged into the first table
        create_new (bool): Whether to create a new table for the merged data

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if not source_table_names or len(source_table_names) < 2:
            print("\u26a0\ufe0f At least two source tables are required for merging")
            return False

        # Use the first table as the target if not specified
        if not target_table_name:
            target_table_name = source_table_names[0]
            source_table_names = source_table_names[1:]  # Remove the first table from sources

        # If creating a new table, we need to fetch the schema from the first source
        if create_new:
            first_table_data = await grist.fetch_table(source_table_names[0])

            if not first_table_data:
                print(f"\u274c Could not fetch data from first source table '{source_table_names[0]}'")
                return False

            # Create a new table with the same schema as the first source
            columns = {}
            for col_name in first_table_data.keys():
                if col_name not in ['id', 'manualSort']:  # Skip system columns
                    # Determine column type based on the data
                    sample_value = None
                    for i in range(len(first_table_data['id'])):
                        if first_table_data[col_name][i] is not None:
                            sample_value = first_table_data[col_name][i]
                            break

                    if isinstance(sample_value, bool):
                        col_type = 'Bool'
                    elif isinstance(sample_value, (int, float)):
                        col_type = 'Numeric'
                    elif isinstance(sample_value, str):
                        col_type = 'Text'
                    else:
                        col_type = 'Text'  # Default to Text for unknown types

                    columns[col_name] = col_type

            # Create the new table
            await create_table(target_table_name, columns)

        # Get the target table schema to know which columns to include
        target_table_data = await grist.fetch_table(target_table_name)
        if not target_table_data:
            print(f"\u274c Could not fetch data from target table '{target_table_name}'")
            return False

        target_columns = [col for col in target_table_data.keys() if col not in ['id', 'manualSort']]

        # Process each source table
        total_rows_merged = 0
        skipped_columns_info = {}

        for source_name in source_table_names:
            # Skip if the source is the same as the target
            if source_name == target_table_name:
                continue

            # Fetch source table data
            source_data = await grist.fetch_table(source_name)

            if not source_data or 'id' not in source_data or len(source_data['id']) == 0:
                print(f"\u26a0\ufe0f No data found in source table '{source_name}'")
                continue

            # Find common columns between source and target
            source_columns = [col for col in source_data.keys() if col not in ['id', 'manualSort']]
            common_columns = [col for col in source_columns if col in target_columns]

            # Track skipped columns for reporting
            skipped_columns = [col for col in source_columns if col not in target_columns]
            if skipped_columns:
                skipped_columns_info[source_name] = skipped_columns

            # Prepare data for the target table, only including common columns
            rows_to_add = []
            for i in range(len(source_data['id'])):
                row = {}
                for col_name in common_columns:
                    row[col_name] = source_data[col_name][i]
                rows_to_add.append(row)

            # Add data to the target table
            if rows_to_add:
                await add_data(target_table_name, rows_to_add)
                total_rows_merged += len(rows_to_add)
                print(f"\u2705 Added {len(rows_to_add)} rows from '{source_name}' to '{target_table_name}'")

        # Report on skipped columns
        if skipped_columns_info:
            print("\n\u26a0\ufe0f Some columns were skipped because they don't exist in the target table:")
            for source_name, columns in skipped_columns_info.items():
                print(f"  - {source_name}: {', '.join(columns)}")

        print(f"\n\u2705 Successfully merged {total_rows_merged} rows into '{target_table_name}'")
        return True

    except Exception as e:
        print(f"\u274c Error merging tables: {e}")
        return False

async def merge_tables(source_table_names, target_table_name=None, create_new=False):
    """
    Merge multiple tables with the same schema into one table.

    Args:
        source_table_names (list): List of table names to merge
        target_table_name (str, optional): Name of the target table. If None, data will be merged into the first table
        create_new (bool): Whether to create a new table for the merged data

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if not source_table_names or len(source_table_names) < 2:
            print("\u26a0\ufe0f At least two source tables are required for merging")
            return False

        # Use the first table as the target if not specified
        if not target_table_name:
            target_table_name = source_table_names[0]
            source_table_names = source_table_names[1:]  # Remove the first table from sources
        elif create_new:
            # If we're creating a new table, we need to fetch the schema from the first source
            first_table_data = await grist.fetch_table(source_table_names[0])

            if not first_table_data:
                print(f"\u274c Could not fetch data from first source table '{source_table_names[0]}'")
                return False

            # Create a new table with the same schema
            columns = {}
            for col_name in first_table_data.keys():
                if col_name not in ['id', 'manualSort']:  # Skip system columns
                    # Determine column type based on the data
                    sample_value = None
                    for i in range(len(first_table_data['id'])):
                        if first_table_data[col_name][i] is not None:
                            sample_value = first_table_data[col_name][i]
                            break

                    if isinstance(sample_value, bool):
                        col_type = 'Bool'
                    elif isinstance(sample_value, (int, float)):
                        col_type = 'Numeric'
                    elif isinstance(sample_value, str):
                        col_type = 'Text'
                    else:
                        col_type = 'Text'  # Default to Text for unknown types

                    columns[col_name] = col_type

            # Create the new table
            await create_table(target_table_name, columns)

        # Process each source table
        total_rows_merged = 0
        for source_name in source_table_names:
            # Skip if the source is the same as the target
            if source_name == target_table_name:
                continue

            # Fetch source table data
            source_data = await grist.fetch_table(source_name)

            if not source_data or 'id' not in source_data or len(source_data['id']) == 0:
                print(f"\u26a0\ufe0f No data found in source table '{source_name}'")
                continue

            # Prepare data for the target table
            rows_to_add = []
            for i in range(len(source_data['id'])):
                row = {}
                for col_name in source_data.keys():
                    if col_name not in ['id', 'manualSort']:  # Skip system columns
                        row[col_name] = source_data[col_name][i]
                rows_to_add.append(row)

            # Add data to the target table
            if rows_to_add:
                await add_data(target_table_name, rows_to_add)
                total_rows_merged += len(rows_to_add)

        print(f"\u2705 Successfully merged {total_rows_merged} rows into '{target_table_name}'")
        return True

    except Exception as e:
        print(f"\u274c Error merging tables: {e}")
        return False

# --- DataFrame Handlers ---

async def create_table_from_dataframe(table_name, df):
    """
    Create a new table from a pandas DataFrame.

    Args:
        table_name (str): Name of the table to create
        df (pandas.DataFrame): DataFrame to convert to a table

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Map pandas dtypes to Grist types
        type_mapping = {
            'int64': 'Numeric',
            'float64': 'Numeric',
            'bool': 'Bool',
            'datetime64[ns]': 'Date',
            'object': 'Text',
            'category': 'Text'
        }

        # Create columns dictionary
        columns = {}
        for col_name, dtype in df.dtypes.items():
            grist_type = type_mapping.get(str(dtype), 'Text')
            columns[col_name] = grist_type

        # Create the table with columns
        table_created = await create_table(table_name, columns)
        if not table_created:
            return False

        # Convert DataFrame to list of dictionaries for Grist
        # Handle NaN values by replacing them with None
        records = df.replace({float('nan'): None}).to_dict('records')

        # Add data to the table
        await add_data(table_name, records)

        print(f"\u2705 Created table '{table_name}' from DataFrame with {len(df)} rows and {len(df.columns)} columns")
        return True

    except Exception as e:
        print(f"\u274c Error creating table from DataFrame: {e}")
        return False

async def fetch_table_to_dataframe(table_name):
    """
    Fetch a Grist table and convert it to a pandas DataFrame.

    Args:
        table_name (str): Name of the table to fetch

    Returns:
        pandas.DataFrame: DataFrame containing the table data
    """
    try:
        import pandas as pd

        # Fetch table data
        table_data = await grist.fetch_table(table_name)

        if not table_data or "id" not in table_data:
            print(f"\u26a0\ufe0f No data found in table '{table_name}'")
            return pd.DataFrame()

        # Convert to DataFrame
        df = pd.DataFrame(table_data)

        # Remove system columns if desired
        if 'manualSort' in df.columns:
            df = df.drop(columns=['manualSort'])

        print(f"\u2705 Fetched table '{table_name}' with {len(df)} rows")
        return df

    except Exception as e:
        print(f"\u274c Error fetching table to DataFrame: {e}")
        return None

# --- Basic Operations ---

async def create_table(table_name, columns):
    """
    Create a new table in Data Management with specified columns.

    Args:
        table_name (str): Name of the table to create
        columns (dict): Dictionary of column names and types (e.g., {"Name": "Text"})

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Create the table
        await grist.raw.docApi.applyUserActions([
            ['AddTable', table_name, []]
        ])

        # Add columns
        column_actions = []
        for col_name, col_type in columns.items():
            column_actions.append(['AddVisibleColumn', table_name, col_name, {'type': col_type}])

        if column_actions:
            await grist.raw.docApi.applyUserActions(column_actions)

        print(f"\u2705 Table '{table_name}' created with {len(columns)} columns")
        return True

    except Exception as e:
        print(f"\u274c Error creating table: {e}")
        return False

async def add_data(table_name, data):
    """
    Add data to an existing table.

    Args:
        table_name (str): Name of the table to add data to
        data (list): List of dictionaries with data to add

    Returns:
        list: List of created row IDs if successful, None otherwise
    """
    try:
        if not data:
            print("\u26a0\ufe0f No data provided to add")
            return []

        # Get table operations
        table_ops = grist.get_table(table_name)

        # Create empty rows first to get IDs
        empty_rows = [{} for _ in range(len(data))]
        create_result = await table_ops.create(empty_rows)

        # Then update each row with actual data using raw docApi
        update_actions = []
        for i, row_data in enumerate(data):
            row_id = create_result[i]['id']
            update_actions.append(['UpdateRecord', table_name, row_id, row_data])

        if update_actions:
            await grist.raw.docApi.applyUserActions(update_actions)

        # Get the row IDs that were created
        row_ids = [row['id'] for row in create_result]
        print(f"\u2705 Added {len(data)} rows to '{table_name}'")
        return row_ids

    except Exception as e:
        print(f"\u274c Error adding data: {e}")
        return None

async def update_table(table_name, new_columns=None, rename_columns=None):
    """
    Update an existing table by adding new columns or renaming existing ones.

    Args:
        table_name (str): Name of the table to update
        new_columns (dict, optional): Dictionary of new column names and types to add
        rename_columns (dict, optional): Dictionary of old column names to new column names

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Add new columns if specified
        if new_columns:
            column_actions = []
            for col_name, col_type in new_columns.items():
                column_actions.append(['AddColumn', table_name, col_name, {'type': col_type}])

            if column_actions:
                await grist.raw.docApi.applyUserActions(column_actions)
                print(f"\u2705 Added {len(new_columns)} new columns to '{table_name}'")

        # Rename columns if specified
        if rename_columns:
            rename_actions = []
            for old_name, new_name in rename_columns.items():
                rename_actions.append(['RenameColumn', table_name, old_name, new_name])

            if rename_actions:
                await grist.raw.docApi.applyUserActions(rename_actions)
                print(f"\u2705 Renamed {len(rename_columns)} columns in '{table_name}'")

        return True

    except Exception as e:
        print(f"\u274c Error updating table: {e}")
        return False

async def delete_data(table_name, row_ids=None, where=None):
    """
    Delete data from a table by row IDs or a filter condition.

    Args:
        table_name (str): Name of the table to delete data from
        row_ids (list, optional): List of row IDs to delete
        where (dict, optional): Dictionary of column-value pairs to filter rows to delete

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if row_ids:
            # Delete specific rows by ID
            delete_actions = []
            for row_id in row_ids:
                delete_actions.append(['RemoveRecord', table_name, row_id])

            if delete_actions:
                await grist.raw.docApi.applyUserActions(delete_actions)
                print(f"\u2705 Deleted {len(row_ids)} rows from '{table_name}'")

        elif where:
            # Fetch table data to find matching rows
            table_data = await grist.fetch_table(table_name)

            if not table_data or "id" not in table_data or len(table_data["id"]) == 0:
                print(f"\u26a0\ufe0f No data found in table '{table_name}'")
                return False

            # Find rows that match the where condition
            matching_row_ids = []
            for i, row_id in enumerate(table_data["id"]):
                matches = True
                for col, value in where.items():
                    if col not in table_data or table_data[col][i] != value:
                        matches = False
                        break

                if matches:
                    matching_row_ids.append(row_id)

            # Delete matching rows
            if matching_row_ids:
                delete_actions = []
                for row_id in matching_row_ids:
                    delete_actions.append(['RemoveRecord', table_name, row_id])

                await grist.raw.docApi.applyUserActions(delete_actions)
                print(f"\u2705 Deleted {len(matching_row_ids)} rows from '{table_name}' based on filter")
            else:
                print("\u26a0\ufe0f No rows matched the filter condition")

        else:
            print("\u26a0\ufe0f Either row_ids or where must be provided")
            return False

        return True

    except Exception as e:
        print(f"\u274c Error deleting data: {e}")
        return False

# --- Bulk Operations ---

async def bulk_add_records(table_name, data):
    """
    Add multiple records using BulkAddRecord.

    Args:
        table_name (str): Table name
        data: List of dicts OR pandas DataFrame

    Returns:
        list: Created row IDs
    """
    if not len(data):
        return []

    # Convert DataFrame to list of dicts if needed
    if isinstance(data, pd.DataFrame):
        data = data.to_dict('records')

    num_records = len(data)
    row_ids = [None] * num_records
    column_values = {}

    for row in data:
        for col_name, value in row.items():
            if col_name not in column_values:
                column_values[col_name] = []
            column_values[col_name].append(value)

    result = await grist.raw.docApi.applyUserActions([
        ['BulkAddRecord', table_name, row_ids, column_values]
    ])

    print(f"✅ Bulk added {num_records} records to '{table_name}'")
    return result

async def bulk_update_records(table_name, updates):
    """
    Update multiple records using BulkUpdateRecord.

    Args:
        table_name (str): Table name
        updates: List of dicts OR DataFrame (must have 'id' column)

    Returns:
        bool: Success status
    """
    if not len(updates):
        return False

    # Convert DataFrame to list of dicts if needed
    if isinstance(updates, pd.DataFrame):
        if 'id' not in updates.columns:
            print("❌ DataFrame must have 'id' column")
            return False
        updates = updates.to_dict('records')

    row_ids = [update['id'] for update in updates]
    column_values = {}

    all_columns = set()
    for update in updates:
        all_columns.update(k for k in update.keys() if k != 'id')

    for col in all_columns:
        column_values[col] = [None] * len(row_ids)

    for idx, update in enumerate(updates):
        for col_name, value in update.items():
            if col_name != 'id':
                column_values[col_name][idx] = value

    await grist.raw.docApi.applyUserActions([
        ['BulkUpdateRecord', table_name, row_ids, column_values]
    ])

    print(f"✅ Bulk updated {len(updates)} records in '{table_name}'")
    return True

async def bulk_delete_records(table_name, row_ids):
    """
    Delete multiple records using BulkRemoveRecord.

    Args:
        table_name (str): Table name
        row_ids: List of IDs OR DataFrame with 'id' column OR Series

    Returns:
        bool: Success status
    """
    # Handle DataFrame or Series
    if isinstance(row_ids, pd.DataFrame):
        if 'id' not in row_ids.columns:
            print("❌ DataFrame must have 'id' column")
            return False
        row_ids = row_ids['id'].tolist()
    elif isinstance(row_ids, pd.Series):
        row_ids = row_ids.tolist()

    if not row_ids:
        return False

    await grist.raw.docApi.applyUserActions([
        ['BulkRemoveRecord', table_name, row_ids]
    ])

    print(f"✅ Bulk deleted {len(row_ids)} records from '{table_name}'")
    return True

async def bulk_delete_where(table_name, where):
    """
    Delete records matching conditions using bulk operations.

    Args:
        table_name (str): Table name
        where: Dict of conditions OR callable function for DataFrame filtering

    Returns:
        bool: Success status
    """
    table_data = await grist.fetch_table(table_name)

    if not table_data or not table_data.get("id"):
        print(f"⚠️ No data found in table '{table_name}'")
        return False

    # Convert to DataFrame for easier filtering
    df = pd.DataFrame(table_data)

    # Apply filter
    if callable(where):
        # Allow custom filter function: where=lambda df: df['Age'] > 30
        mask = where(df)
        matching_ids = df[mask]['id'].tolist()
    else:
        # Dict-based filtering
        mask = pd.Series([True] * len(df))
        for col, value in where.items():
            mask &= (df[col] == value)
        matching_ids = df[mask]['id'].tolist()

    if matching_ids:
        return await bulk_delete_records(table_name, matching_ids)
    else:
        print("⚠️ No rows matched the filter condition")
        return False

async def bulk_merge_tables(source_tables, target_table, create_new=False):
    """
    Merge multiple tables using bulk operations.

    Args:
        source_tables (list): List of source table names
        target_table (str): Target table name
        create_new (bool): Create target table if True

    Returns:
        bool: Success status
    """
    if create_new:
        first_data = await grist.fetch_table(source_tables[0])
        if not first_data:
            print(f"❌ Could not fetch data from '{source_tables[0]}'")
            return False

        columns = {}
        for col_name in first_data.keys():
            if col_name not in ['id', 'manualSort']:
                sample_value = None
                for i in range(len(first_data['id'])):
                    if first_data[col_name][i] is not None:
                        sample_value = first_data[col_name][i]
                        break

                if isinstance(sample_value, bool):
                    columns[col_name] = 'Bool'
                elif isinstance(sample_value, (int, float)):
                    columns[col_name] = 'Numeric'
                else:
                    columns[col_name] = 'Text'

        await create_table(target_table, columns)

    total_merged = 0
    for source_table in source_tables:
        data = await grist.fetch_table(source_table)

        if not data or not data.get("id"):
            continue

        num_rows = len(data["id"])
        row_ids = [None] * num_rows
        column_values = {
            col: data[col]
            for col in data.keys()
            if col not in ['id', 'manualSort']
        }

        await grist.raw.docApi.applyUserActions([
            ['BulkAddRecord', target_table, row_ids, column_values]
        ])

        total_merged += num_rows
        print(f"✅ Merged {num_rows} rows from '{source_table}'")

    print(f"\n✅ Total merged: {total_merged} rows into '{target_table}'")
    return True