import pandas as pd
from typing import Any, Dict, List, Optional, Union


class KeywardApi:
    def __init__(self):
        self.connected = True
        # Import grist API at initialization
        try:
            import grist
            self.grist = grist
            self.has_grist = True
        except ImportError:
            print("Warning: Grist API not available")
            self.grist = None
            self.has_grist = False

    async def create_table(self, table_name, columns):
        """Creates a table with specified columns"""
        from .table_operations import table_operations
        return await table_operations.create_table(table_name, columns)

    async def add_record(self, table_name, record):
        """Add a single record to a table"""
        from .table_operations import table_operations
        return await table_operations.add_data(table_name, record)

    async def add_records(self, table_name, records):
        """Add multiple records to a table"""
        from .table_operations import table_operations
        return await table_operations.add_data(table_name, records)

    async def get_table(self, table_name):
        """Get table data as a DataFrame"""
        from .table_operations import table_operations
        return await table_operations.fetch_table_to_dataframe(table_name)

    async def update_record(self, table_name, record_id, updates):
        """Update a record in a table"""
        from .table_operations import table_operations
        return await table_operations.update_table(table_name, record_id, updates)

    async def delete_record(self, table_name, record_id):
        """Delete a record from a table"""
        from .table_operations import table_operations
        return await table_operations.delete_data(table_name, record_id)

    async def create_from_dataframe(self, table_name, dataframe):
        """Create a table from a pandas DataFrame"""
        from .table_operations import table_operations
        return await table_operations.create_table_from_dataframe(table_name, dataframe)

    async def bulk_update_records(self, table_name, updates):
        """Update multiple records at once"""
        from .table_operations import table_operations
        return await table_operations.bulk_update_records(table_name, updates)

    async def bulk_delete_records(self, table_name, record_ids):
        """Delete multiple records at once"""
        from .table_operations import table_operations
        return await table_operations.bulk_delete_records(table_name, record_ids)

    async def get_row_ids(self, table_name):
        """Get row IDs for a table"""
        try:
            if not self.has_grist:
                return []
            
            table_data = await self.grist.get_table(table_name)
            records = await table_data.fetch_table()
            return [r.get('id') for r in records if 'id' in r]
        except Exception as e:
            print(f"❌ Error getting row IDs: {e}")
            return []

    async def merge_tables(self, sources, target=None, create_new=False):
        """Merge tables together"""
        from .table_operations import table_operations
        return await table_operations.merge_tables(sources, target, create_new)

    async def list_tables(self):
        """List all available tables"""
        try:
            if not self.has_grist:
                return []
            
            # Try to get list of tables from document
            tables = await self.grist.list_tables()
            return tables
        except AttributeError:
            # Fallback method if list_tables doesn't exist
            try:
                doc_info = await self.grist.get_document()
                if isinstance(doc_info, dict) and 'tables' in doc_info:
                    return doc_info['tables']
            except:
                pass
        except Exception as e:
            print(f"❌ Error listing tables: {e}")
        
        return []

    async def remove_table(self, table_name):
        """Remove a table (clears all records)"""
        try:
            if not self.has_grist:
                return False
            
            # Get all row IDs and delete them
            row_ids = await self.get_row_ids(table_name)
            if row_ids:
                from .table_operations import table_operations
                return await table_operations.delete_data(table_name, row_ids)
            return True
        except Exception as e:
            print(f"❌ Error removing table: {e}")
            return False

    async def rename_table(self, old_name, new_name):
        """Rename a table by copying and removing old one"""
        try:
            if not self.has_grist:
                return False
            
            # Get all data from old table
            from .table_operations import table_operations
            
            # Fetch old table as DataFrame
            df = await table_operations.fetch_table_to_dataframe(old_name)
            
            if df.empty:
                print(f"❌ Table '{old_name}' is empty or doesn't exist")
                return False
            
            # Create new table with data
            result = await table_operations.create_table_from_dataframe(new_name, df)
            
            if result:
                # Remove old table
                await self.remove_table(old_name)
                print(f"✅ Renamed table '{old_name}' to '{new_name}'")
                return True
            
            return False
        except Exception as e:
            print(f"❌ Error renaming table: {e}")
            return False

    async def get_table_schema(self, table_name):
        """Get the schema/structure of a table"""
        try:
            if not self.has_grist:
                return {}
            
            table_data = await self.grist.get_table(table_name)
            records = await table_data.fetch_table()
            
            if not records:
                return {}
            
            # Analyze first record to determine schema
            schema = {}
            first_record = records[0]
            
            for col, val in first_record.items():
                if col not in ['id', 'manualSort'] and not col.startswith('_'):
                    if isinstance(val, bool):
                        schema[col] = 'Bool'
                    elif isinstance(val, (int, float)):
                        schema[col] = 'Numeric'
                    elif isinstance(val, str):
                        schema[col] = 'Text'
                    elif val is None:
                        schema[col] = 'Any'
                    else:
                        schema[col] = 'Any'
            
            return schema
        except Exception as e:
            print(f"❌ Error getting table schema: {e}")
            return {}

    async def query_table(self, table_name, filters=None, columns=None, limit=None):
        """Query a table with optional filters and column selection"""
        try:
            if not self.has_grist:
                return []
            
            table_data = await self.grist.get_table(table_name)
            records = await table_data.fetch_table()
            
            # Apply filters if provided
            if filters:
                filtered_records = []
                for record in records:
                    match = True
                    for col, val in filters.items():
                        if col in record and record[col] != val:
                            match = False
                            break
                    if match:
                        filtered_records.append(record)
                records = filtered_records
            
            # Select specific columns if provided
            if columns:
                records = [{col: r.get(col) for col in columns} for r in records]
            else:
                # Remove system columns
                records = [{k: v for k, v in r.items() 
                          if not k.startswith('_') and k not in ['id', 'manualSort']} 
                          for r in records]
            
            # Apply limit if provided
            if limit and limit > 0:
                records = records[:limit]
            
            return records
        except Exception as e:
            print(f"❌ Error querying table: {e}")
            return []

    async def count_records(self, table_name, filters=None):
        """Count records in a table with optional filters"""
        try:
            records = await self.query_table(table_name, filters=filters)
            return len(records)
        except Exception as e:
            print(f"❌ Error counting records: {e}")
            return 0

    # Proxy method for direct access to Grist functions
    def __getattr__(self, name):
        # Try to find method in Grist object
        if self.grist and hasattr(self.grist, name):
            return getattr(self.grist, name)
        
        # Not found
        raise AttributeError(f"'KeywardApi' has no attribute '{name}'")


# Create a singleton instance
api = KeywardApi()