import pandas as pd
from typing import Any, Dict, List, Optional, Union


class KeywardApi:
    def __init__(self):
        self.connected = True
        # Import grist API at initialization
        try:
            import grist.browser.api as gapi

            self.gapi = gapi
            self.grist = gapi.grist
        except ImportError:
            print("Warning: Grist API not available")
            self.gapi = None
            self.grist = None

    async def create_table(self, table_name, columns):
        """Creates a table with specified columns"""
        from .table_operations import table_operations

        return await table_operations.create_table(table_name, columns)

    async def add_record(self, table_name, record):
        """Add a single record to a table"""
        from .table_operations import table_operations

        return await table_operations.add_data(table_name, record)

    async def add_records(self, table_name, records):
        """Add multiple records to a table"""
        from .table_operations import table_operations

        return await table_operations.add_data(table_name, records)

    async def get_table(self, table_name):
        """Get table data as a DataFrame"""
        from .table_operations import table_operations

        return await table_operations.fetch_table_to_dataframe(table_name)

    async def update_record(self, table_name, record_id, updates):
        """Update a record in a table"""
        from .table_operations import table_operations

        return await table_operations.update_table(table_name, record_id, updates)

    async def delete_record(self, table_name, record_id):
        """Delete a record from a table"""
        from .table_operations import table_operations

        return await table_operations.delete_data(table_name, record_id)

    async def create_from_dataframe(self, table_name, dataframe):
        """Create a table from a pandas DataFrame"""
        from .table_operations import table_operations

        return await table_operations.create_table_from_dataframe(table_name, dataframe)

    async def bulk_update_records(self, table_name, updates):
        """Update multiple records at once"""
        from .table_operations import table_operations

        try:
            table_ops = self.gapi.TableOperations(self.grist, table_name)
            await table_ops.update(updates)
            return True
        except Exception as e:
            print(f"❌ Error bulk updating records: {e}")
            return False

    async def bulk_delete_records(self, table_name, record_ids):
        """Delete multiple records at once"""
        from .table_operations import table_operations

        return await table_operations.delete_data(table_name, record_ids)

    async def get_row_ids(self, table_name):
        """Get row IDs for a table"""
        try:
            table_data = await self.grist.fetch_table(table_name)
            return table_data.get("id", [])
        except Exception as e:
            print(f"❌ Error getting row IDs: {e}")
            return []

    async def merge_tables(self, sources, target=None, create_new=False):
        """Merge tables together"""
        from .table_operations import table_operations

        try:
            if len(sources) < 1:
                return False

            tgt = target if target else sources[0]
            srcs = sources if target else sources[1:]

            # Create target table if needed
            if create_new and srcs:
                # Fetch schema from first source
                first_source_data = await self.grist.fetch_table(srcs[0])

                # Determine column types
                type_map = {
                    "int": "Numeric",
                    "float": "Numeric",
                    "bool": "Bool",
                    "str": "Text",
                    "NoneType": "Text",
                }

                cols = {}
                for col in first_source_data:
                    if col not in ("id", "manualSort"):
                        # Get non-None value to determine type
                        sample = next(
                            (v for v in first_source_data[col] if v is not None), None
                        )
                        col_type = type_map.get(type(sample).__name__, "Text")
                        cols[col] = col_type

                # Create the target table
                await self.create_table(tgt, cols)

            # Copy data from each source
            for src in srcs:
                src_data = await self.grist.fetch_table(src)

                # Convert to records
                records = []
                row_count = len(src_data.get("id", []))

                for i in range(row_count):
                    record = {}
                    for col in src_data:
                        if col not in ("id", "manualSort") and i < len(src_data[col]):
                            record[col] = src_data[col][i]
                    records.append(record)

                # Add to target table
                if records:
                    await self.add_records(tgt, records)

            return True
        except Exception as e:
            print(f"❌ Error merging tables: {e}")
            return False

    async def list_tables(self):
        """List all available tables"""
        try:
            tables = await self.grist.fetch_selected_table()
            return tables
        except Exception as e:
            print(f"❌ Error listing tables: {e}")
            return []

    async def remove_table(self, table_name):
        """Remove a table"""
        from .table_operations import table_operations

        try:
            # Implement table removal via browser API
            table_ops = self.gapi.TableOperations(self.grist, table_name)
            # This is a workaround since direct table removal may not be available
            # It's safer to just clear all records
            table_data = await self.grist.fetch_table(table_name)
            row_ids = table_data.get("id", [])
            if row_ids:
                await table_ops.destroy(row_ids)
            return True
        except Exception as e:
            print(f"❌ Error removing table: {e}")
            return False

    async def rename_table(self, old_name, new_name):
        """Rename a table"""
        try:
            # This is a workaround - copy table to new name and remove old one
            old_data = await self.grist.fetch_table(old_name)

            # Get column types
            type_map = {
                "int": "Numeric",
                "float": "Numeric",
                "bool": "Bool",
                "str": "Text",
                "NoneType": "Text",
            }

            # Create new table with same schema
            cols = {}
            for col in old_data:
                if col not in ("id", "manualSort"):
                    sample = next((v for v in old_data[col] if v is not None), None)
                    col_type = type_map.get(type(sample).__name__, "Text")
                    cols[col] = col_type

            await self.create_table(new_name, cols)

            # Copy data
            records = []
            row_count = len(old_data.get("id", []))
            for i in range(row_count):
                record = {}
                for col in old_data:
                    if col not in ("id", "manualSort") and i < len(old_data[col]):
                        record[col] = old_data[col][i]
                records.append(record)

            if records:
                await self.add_records(new_name, records)

            # Remove old table
            await self.remove_table(old_name)

            return True
        except Exception as e:
            print(f"❌ Error renaming table: {e}")
            return False

    # Proxy method for direct access to Grist functions
    def __getattr__(self, name):
        # First try to find method in Grist object
        if self.grist and hasattr(self.grist, name):
            return getattr(self.grist, name)

        # Then try in gapi
        if self.gapi and hasattr(self.gapi, name):
            return getattr(self.gapi, name)

        # Not found
        raise AttributeError(f"'KeywardApi' has no attribute '{name}'")


# Create a singleton instance
api = KeywardApi()
